import React from 'react';

function App() {
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Anatomy Flashcards</h1>
      <p>React app is working!</p>
    </div>
  );
}

export default App;
